<?php

define('ABSOLUTE_PATH', '/home/amalane/htdocs/CIT313/SP2018/a1');
define('URL_ROOT', '/CIT313/SP2018/a1/');